/* 写一个程序，每次读取一个单词 */
#include<iostream>
using namespace std;
int main(){
	string words;
	while(cin>>words)
		cout<<words<<endl;
	return 0;
}


